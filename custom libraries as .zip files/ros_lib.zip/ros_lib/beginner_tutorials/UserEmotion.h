#ifndef _ROS_beginner_tutorials_UserEmotion_h
#define _ROS_beginner_tutorials_UserEmotion_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace beginner_tutorials
{

  class UserEmotion : public ros::Msg
  {
    public:
      typedef float _happy_type;
      _happy_type happy;
      typedef float _sad_type;
      _sad_type sad;
      typedef float _angry_type;
      _angry_type angry;
      typedef float _bored_type;
      _bored_type bored;
      typedef float _sleepy_type;
      _sleepy_type sleepy;

    UserEmotion():
      happy(0),
      sad(0),
      angry(0),
      bored(0),
      sleepy(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const override
    {
      int offset = 0;
      union {
        float real;
        uint32_t base;
      } u_happy;
      u_happy.real = this->happy;
      *(outbuffer + offset + 0) = (u_happy.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_happy.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_happy.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_happy.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->happy);
      union {
        float real;
        uint32_t base;
      } u_sad;
      u_sad.real = this->sad;
      *(outbuffer + offset + 0) = (u_sad.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_sad.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_sad.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_sad.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->sad);
      union {
        float real;
        uint32_t base;
      } u_angry;
      u_angry.real = this->angry;
      *(outbuffer + offset + 0) = (u_angry.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_angry.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_angry.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_angry.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->angry);
      union {
        float real;
        uint32_t base;
      } u_bored;
      u_bored.real = this->bored;
      *(outbuffer + offset + 0) = (u_bored.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_bored.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_bored.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_bored.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->bored);
      union {
        float real;
        uint32_t base;
      } u_sleepy;
      u_sleepy.real = this->sleepy;
      *(outbuffer + offset + 0) = (u_sleepy.base >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (u_sleepy.base >> (8 * 1)) & 0xFF;
      *(outbuffer + offset + 2) = (u_sleepy.base >> (8 * 2)) & 0xFF;
      *(outbuffer + offset + 3) = (u_sleepy.base >> (8 * 3)) & 0xFF;
      offset += sizeof(this->sleepy);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer) override
    {
      int offset = 0;
      union {
        float real;
        uint32_t base;
      } u_happy;
      u_happy.base = 0;
      u_happy.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_happy.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_happy.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_happy.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->happy = u_happy.real;
      offset += sizeof(this->happy);
      union {
        float real;
        uint32_t base;
      } u_sad;
      u_sad.base = 0;
      u_sad.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_sad.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_sad.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_sad.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->sad = u_sad.real;
      offset += sizeof(this->sad);
      union {
        float real;
        uint32_t base;
      } u_angry;
      u_angry.base = 0;
      u_angry.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_angry.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_angry.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_angry.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->angry = u_angry.real;
      offset += sizeof(this->angry);
      union {
        float real;
        uint32_t base;
      } u_bored;
      u_bored.base = 0;
      u_bored.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_bored.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_bored.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_bored.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->bored = u_bored.real;
      offset += sizeof(this->bored);
      union {
        float real;
        uint32_t base;
      } u_sleepy;
      u_sleepy.base = 0;
      u_sleepy.base |= ((uint32_t) (*(inbuffer + offset + 0))) << (8 * 0);
      u_sleepy.base |= ((uint32_t) (*(inbuffer + offset + 1))) << (8 * 1);
      u_sleepy.base |= ((uint32_t) (*(inbuffer + offset + 2))) << (8 * 2);
      u_sleepy.base |= ((uint32_t) (*(inbuffer + offset + 3))) << (8 * 3);
      this->sleepy = u_sleepy.real;
      offset += sizeof(this->sleepy);
     return offset;
    }

    virtual const char * getType() override { return "beginner_tutorials/UserEmotion"; };
    virtual const char * getMD5() override { return "45bd6133bdb210808e6b63be6d218ca6"; };

  };

}
#endif
